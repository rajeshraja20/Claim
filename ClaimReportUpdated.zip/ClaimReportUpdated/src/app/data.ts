export const CLIAM_DATA= [
    {
        userId: 0,
        patientName: "John Smith",
        claimNumber: "11111",
        dateSubmited: "11/08/2019",
        status: "Not received",
        files:[
            {
                name:"",
                size: ""
            }
        ]
    },
    {
        userId: 1,
        patientName: "Steve B",
        claimNumber: "22222",
        dateSubmited: "11/08/2019",
        status: "Not received",
        files:[
            {
                name:"",
                size: ""
            }
        ]
    },
    {
        userId: 2,
        patientName: "Peter",
        claimNumber: "333333",
        dateSubmited: "11/08/2019",
        status: "Not received",
        files:[
            {
                name:"",
                size: ""
            }
        ]
    }
]
